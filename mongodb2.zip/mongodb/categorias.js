const mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);

var CategoriasSchema = new mongoose.Schema ({
  codigoUnico: String,
  categoriaGeneral: String,
  prioridad: String,
  titulo: String,
  subtitulo: String,
  imagen: [ 
    {
      _id: false,
      URL: { type: String, default: '0'} , 
      nombreInterno: { type: String, default: '0'} ,
      nombreExterior: { type: String, default:  '0'} ,
      tipo: { type: String, default:  '0'} ,
      fechaCreacion: { type: Date, default: Date.now } 
    } ]
});


module.exports  = mongoose.model('model1', CategoriasSchema, 'test');