const express = require("express");
const bodyParser = require('body-parser');
const app = express();

const fileUpload = require('express-fileupload');
const cors = require('cors');

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


//configuracion de cabeceras
app.use((req, res, next)=>{
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Authorization, X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
})

app.use(cors());
app.use(fileUpload({
    limits: { fileSize: 4 * 1024 * 1024 },
}));

app.use((err,req,res,next)=>{
    if(err.name === 'UnauthorizedError'){
        res.status(401).json({error:err.message});
    }
});



require('./connection'); 


const Categoria = require('./categorias'); 
const Store = require('./stores'); 


app.get('/', (req, res ) => {  
	res.send({  mensaje: 'Pagina Principal' }) 
});

//CATEGORIAS

app.get('/test', (req, res) =>{
	Categoria.find({}, 'titulo codigoUnico', (err, categorias)=> {
		if(err) return res.status(500).send({message:'Error al realizar la peticion'});
		if(!categorias) return res.status(404).send({message:'No existen categorias'})
		res.status(200).send({ categorias })
	}) 	
 });


app.post('/test', function (req, res) {

  var CategoriaN = new Categoria ({
	  codigoUnico: req.body.codigoUnico,
 	  categoriaGeneral: req.body.categoriaGeneral,
	  prioridad: req.body.prioridad,
	  titulo: req.body.titulo,
	  subtitulo: req.body.subtitulo,
	  imagen: req.body.imagen
	});

  CategoriaN.save((err) => {
  if (err) res.status(500).send({message: "Error al guardar la categoria"})
  res.status(200).send({  menssage: 'Categoria guardada exitosamente!' });
  });
  
});


app.get('/test/:codigounico', (req, res) =>{
	let categoriaid = req.params.codigounico

	Categoria.find( {codigoUnico: categoriaid}, (err,categoria) => {
		if(err) return res.status(500).send({message:' Error al realizar la peticion'});
		if(!categoria) return res.status(404).send({message:'La Categoria no existe, ID incorrecta'})
		res.status(200).send({ categoria })
	}) 
 });


app.put('/test/:codigounico', (req, res) =>{
	let categoriaid = req.params.codigounico
	let update = req.body
	
 	Categoria.findAndUpdate( {codigoUnico: categoriaid}, update, (err) => {
		if(err) return res.status(500).send({message:' Error al actualizar la categoria'});
		res.status(200).send({message: 'Categoria actualizada exitosamente!'})
		})		
}) 







//STORES

 app.get('/stores', (req, res) =>{
	Store.find({}, 'nombreEmpresa codigoUnico', (err, stores)=> {
		if(err) return res.status(500).send({message:' Error al realizar la peticion'});
		if(!stores) return res.status(404).send({message:'No existen Stores'})
		res.status(200).send({ stores })
	}) 	
 });



app.post('/stores', function (req, res) {


	function randnum (){
		let caracteres = "0123456789";
		let identificador = "";
		let i;
		let digitos = 7;
		for (i=0; i<digitos; i++) identificador +=caracteres.charAt(Math.floor(Math.random()*caracteres.length));
		return identificador;
	}

	var StoreN = new Store ({
		codigoUnico: req.body.codigoUnico+randnum(),
		ruc: req.body.ruc,
		ci: req.body.ci,
		nombreRepresentante: req.body.nombreRepresentante,
		habilitacionVentas: req.body.habilitacionVentas,
		link: req.body.link,
		departamento: req.body.departamento,
		nombreEmpresa: req.body.nombreEmpresa,
		mision: req.body.mensaje,
		areaPrincipal: req.body.areaPrincipal,
		ubicacion: req.body.ubicacion,
		direccion: req.body.direccion,
		telefonos: req.body.telefonos,
		imagenURL: req.body.imagenURL
	});

	
	var STRID = {};

	Store.find({}, 'codigoUnico', (err, stores)=> {
	   if(err) return res.status(500).send({message:' Error al realizar la peticion'});
	   for (i in stores ) {
		   STRID[i] = stores[i].codigoUnico }			
   	}) 	


	var k = 0;	
	for (j in STRID) {
		if ( StoreN.codigoUnico == STRID[j] ) {
				StoreN.codigoUnico = req.body.codigoUnico+randnum();
				j = 0;
				k++;
				if (k==20){break}
			}
	}
		
	
	StoreN.save((err) => {
		if (err) res.status(500).send({message: "Error al guardar la store"})
		res.status(200).send({  menssage: 'Store guardada exitosamente!' });
	});	
		

});


app.get('/stores/:codigounico', (req, res) =>{
	let storeid = req.params.codigounico

	Store.find(  {codigoUnico: storeid}, (err,store) => {
		if(err) return res.status(500).send({message:' Error al realizar la peticion'});
		if(!store) return res.status(404).send({message:'Store desconocida, ID incorrecta'})
		res.status(200).send({ store })
	}) 
 });


 app.put('/stores/:codigounico', (req, res) =>{
	let storeid = req.params.codigounico
	let update = req.body
	
 	Store.findAndUpdate({codigoUnico: storeid}, update, (err) => {
		if(err) return res.status(500).send({message:' Error al actualizar la Store'});
		res.status(200).send({message: 'Store actualizada exitosamente!'})
		})		
}) 


/* app.delete('/stores/:storeId', (req, res) =>{
	let storeid = req.params.storeId
	
 	Store.findById(storeid, (err,store) => {
		if(err) return res.status(500).send({message:' Error al borrar la Store'});
	store.remove (err => {
		if(err) return res.status(500).send({message:' Error al borrar la Store'});
		res.status(200).send({message: 'Store eliminada'})
		})		
	}) 
 }); */



 app.listen(80, () => { console.log("Servicio iniciado en el puerto 80")})
