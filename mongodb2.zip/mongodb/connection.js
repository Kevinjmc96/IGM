const mongoose = require('mongoose');
mongoose.set('useFindAndModify', false);

mongoose.connect('mongodb://52.43.113.195:38510/UshopsDatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;

db.on('error', function(err){
  console.log('Connection Error', err)
})

db.once('open', function(){
  console.log('Connection Successful')
})