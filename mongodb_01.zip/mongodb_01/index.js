const express = require("express");
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

require('./connection'); 


const Categoria = require('./categorias'); 
const Store = require('./stores'); 


app.get('/', (req, res ) => {  
	res.send({  mensaje: 'Pagina Principal' }) 
});

//CATEGORIAS

app.get('/categoria', (req, res) =>{
	Categoria.find({}, 'titulo', (err, categorias)=> {
		if(err) return res.status(500).send({message:' Error al realizar la peticion'});
		if(!categorias) return res.status(404).send({message:'No existen categorias'})
		res.status(200).send({ categorias })
	}) 	
 });


app.post('/categoria', function (req, res) {

  var CategoriaN = new Categoria ({
	  codigoUnico: req.body.codigoUnico,
 	  categoriaGeneral: req.body.categoriaGeneral,
	  prioridad: req.body.prioridad,
	  titulo: req.body.titulo,
	  subtitulo: req.body.subtitulo,
	  imagen: req.body.imagen
	});

  CategoriaN.save((err) => {
  if (err) res.status(500).send({message: "Error al guardar la categoria"})
  res.status(200).send({  menssage: 'Categoria guardada exitosamente!' });
  });
  
});


app.get('/categoria/:categoriaId', (req, res) =>{
	let categoriaid = req.params.categoriaId

	Categoria.findById(categoriaid, (err,categoria) => {
		if(err) return res.status(500).send({message:' Error al realizar la peticion'});
		if(!categoria) return res.status(404).send({message:'La Categoria no existe, ID incorrecta'})
		res.status(200).send({ categoria })
	}) 
 });


app.put('/categoria/:categoriaId', (req, res) =>{
	let categoriaid = req.params.categoriaId
	let update = req.body
	
 	Categoria.findByIdAndUpdate(categoriaid, update, (err) => {
		if(err) return res.status(500).send({message:' Error al actualizar la categoria'});
		res.status(200).send({message: 'Categoria actualizada exitosamente!'})
		})		
}) 


/* app.delete('/categoria/:categoriaId', (req, res) =>{
	let categoriaid = req.params.categoriaId
	
 	Categoria.findById(categoriaid, (err,categoria) => {
		if(err) return res.status(500).send({message:' Error al borrar la categoria'});
	categoria.remove (err => {
		if(err) return res.status(500).send({message:' Error al borrar la categoria'});
		res.status(200).send({message: 'Categoria eliminada'})
		})		
	}) 
 });
 */




//STORES

 app.get('/store', (req, res) =>{
	Store.find({}, 'nombreEmpresa', (err, stores)=> {
		if(err) return res.status(500).send({message:' Error al realizar la peticion'});
		if(!stores) return res.status(404).send({message:'No existen Stores'})
		res.status(200).send({ stores })
	}) 	
 });


app.post('/store', function (req, res) {

	var StoreN = new Store ({
		codigoUnico: req.body.codigoUnico,
		habilitacionVentas: req.body.habilitacionVentas,
		link: req.body.link,
		departamento: req.body.departamento,
		nombreEmpresa: req.body.nombreEmpresa,
		mision: req.body.mensaje,
		areaPrincipal: req.body.areaPrincipal,
		ubicacion: req.body.ubicacion,
		direccion: req.body.direccion,
		telefonos: req.body.telefonos,
		imagenURL: req.body.imagenURL
	});
  
	StoreN.save((err) => {
		if (err) res.status(500).send({message: "Error al guardar la store"})
		res.status(200).send({  menssage: 'Store guardada exitosamente!' });
	});	
});


app.get('/store/:storeId', (req, res) =>{
	let storeid = req.params.storeId

	Store.findById(storeid, (err,store) => {
		if(err) return res.status(500).send({message:' Error al realizar la peticion'});
		if(!store) return res.status(404).send({message:'Store desconocida, ID incorrecta'})
		res.status(200).send({ store })
	}) 
 });


 app.put('/store/:storeId', (req, res) =>{
	let storeid = req.params.storeId
	let update = req.body
	
 	Store.findByIdAndUpdate(storeid, update, (err) => {
		if(err) return res.status(500).send({message:' Error al actualizar la Store'});
		res.status(200).send({message: 'Store actualizada exitosamente!'})
		})		
}) 


/* app.delete('/store/:storeId', (req, res) =>{
	let storeid = req.params.storeId
	
 	Store.findById(storeid, (err,store) => {
		if(err) return res.status(500).send({message:' Error al borrar la Store'});
	store.remove (err => {
		if(err) return res.status(500).send({message:' Error al borrar la Store'});
		res.status(200).send({message: 'Store eliminada'})
		})		
	}) 
 }); */



 app.listen(80, () => { console.log("Servicio iniciado en el puerto 80")})
